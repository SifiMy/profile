---
date: 23 March 2021
author: Sifi My
category: Wordpress
---

![Boost your post for increasing sales](/images/blog/internet.jpg)

### Being Anonymous is way more Fun
There is a time where being anonymous is way more fun than being famous. But there is also a time that everyone wants to have atleast a little of fame.
This is common as a human being. If you are reading this, probably because you feel the same. 

> But when is it the time that being unknown is fun?

> Wait a minute, there is a difference from being anonymous than unknown. Because being anonymous is that people can know you but do not know who you are. 

Anyway, is it that important to know everything yet understand nothing? Or is it just as much important to know nothing and understand a lot? Let me know in the comments what you think?
Some time, the best answer is by questioning one self. So, maybe you already know and understand, but just wants a confirmation. Or maybe its just a thought. Who knows right? 



[my vlog site]( https://youtu.be/6O1OrbyUvE )

I hope this content is helful and happy journey ahead!.
