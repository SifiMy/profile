---
date: 26 Oktober 2023
author: Sifi My
category: Wordpress
---

![Boost your post for increasing sales](/images/blog/wordpress-logo.png)

### My Truth About Wordpress
Without worpress I would'nt be starting a career in web development, or better yet software development. I never would have though I went this far as to be a full stack developer. All started from tingling with wordpress. At first I just wanted to share my content to the world about scammers. Than I started a front end job by doing css, html and javascript( to be specific JQuery). At this time, facebook hasn't been born yet. I was good money. After a long a painful road along the way, I found that wordpress has been too popular for any beginner to event took advantage of it. From my intention of 'Not Wanting Scammers' to even know about internet, it went the other way around. So, I took upon myself to be an expert in web development. At this stage, I could say a very important factor for anyone who is even thinking about letting yourself being 'raped' on the internet
1. Never use wordpress other than publishing content!
2. Never use wordpress for a real money transaction!
3. Never use wordpress to save important data!

> Wordpress are only for beginners! Period! If you gain traffic by wordpress, think further. Dont stick to it.

Before you judge me from critising wordpress if you love them, I love wordpress Too!! But not for other than publishing a content for people to scrap. The internet are a scarry place for people who doesn't understand them. Look at my vlog and tell me if I didn't use 
[wordpress before]( https://youtu.be/6O1OrbyUvE )

I hope this content is helpful for a new starters and happy journey ahead!.
