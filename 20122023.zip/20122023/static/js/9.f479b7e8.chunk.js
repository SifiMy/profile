(this.webpackJsonpsifi=this.webpackJsonpsifi||[]).push([[9],{136:function(i,s,t){"use strict";t.r(s),s.default=t.p+"static/media/iphone-8.c5ec8406.md"}}]);
//# sourceMappingURL=9.f479b7e8.chunk.js.map